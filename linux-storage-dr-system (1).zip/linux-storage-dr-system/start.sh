#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
[[ -x .venv/bin/uvicorn ]] || { echo "Run ./install.sh first"; exit 1; }
mkdir -p logs data backups
if [[ -f .linuxdr-backend.pid ]] && kill -0 "$(cat .linuxdr-backend.pid)" 2>/dev/null; then echo "Backend already running (PID $(cat .linuxdr-backend.pid))"; else
  (cd backend && ../.venv/bin/uvicorn app.main:app --env-file .env --host 127.0.0.1 --port 8000) > logs/backend.log 2>&1 &
  echo $! > .linuxdr-backend.pid
fi
if [[ -f .linuxdr-frontend.pid ]] && kill -0 "$(cat .linuxdr-frontend.pid)" 2>/dev/null; then echo "Frontend already running (PID $(cat .linuxdr-frontend.pid))"; else
  (cd frontend && npm run dev -- --host 127.0.0.1) > logs/frontend.log 2>&1 &
  echo $! > .linuxdr-frontend.pid
fi
sleep 2
if curl -fsS http://127.0.0.1:8000/api/v1/health >/dev/null; then echo "Backend healthy: http://127.0.0.1:8000/docs"; else echo "Backend may not have started. Check logs/backend.log"; fi
echo "Frontend: http://127.0.0.1:5173"
