from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[2]
def env_bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}

SIMULATION_MODE = env_bool("SIMULATION_MODE", True)
DATA_DIR = Path(os.getenv("DATA_DIR", str(ROOT / "data"))).resolve()
BACKUP_DIR = Path(os.getenv("BACKUP_DIR", str(ROOT / "backups"))).resolve()
WARNING_THRESHOLD = int(os.getenv("WARNING_THRESHOLD", "75"))
CRITICAL_THRESHOLD = int(os.getenv("CRITICAL_THRESHOLD", "90"))
DB_PATH = DATA_DIR / "linuxdr.sqlite3"
