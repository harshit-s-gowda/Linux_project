# Test report

- Date / environment:
- Git revision:
- Python version:
- Node/npm version:
- Install command result:
- Backend test command and result:
- Frontend build command and result:
- Health endpoint result:
- Backup create / verify / restore test result:
- Known failures:
- Reviewer:
