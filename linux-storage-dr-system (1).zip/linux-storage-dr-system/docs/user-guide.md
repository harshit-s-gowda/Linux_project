# User guide

- Dashboard: summary cards, saved measurements, backup list.
- Storage Management: read-only device/filesystem inventory.
- Backup & Recovery: create a full archive from a directory you own, verify its checksum/archive structure, and run an isolated restore test.
- Intelligence Center: view a simple trend estimate after at least three samples.
- Alerts: view threshold alerts and acknowledge them.

The default source for the backup demo is `../sample-data` from the backend process working directory, but the frontend sends this path and backend resolves it from its current process directory. If path resolution fails, use the absolute path to the project's `sample-data` folder.
