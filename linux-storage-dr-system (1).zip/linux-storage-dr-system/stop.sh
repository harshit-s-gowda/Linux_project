#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for item in backend frontend; do
  pidfile="$ROOT/.linuxdr-$item.pid"
  if [[ -f "$pidfile" ]]; then
    pid="$(cat "$pidfile")"
    if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null; then kill "$pid" || true; fi
    rm -f "$pidfile"
    echo "Stopped project $item process (if it was running)."
  fi
done
