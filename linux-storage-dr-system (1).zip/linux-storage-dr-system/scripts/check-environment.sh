#!/usr/bin/env bash
set -u
for cmd in python3 npm curl df lsblk tar gzip; do
  if command -v "$cmd" >/dev/null 2>&1; then printf 'OK      %s: %s\n' "$cmd" "$(command -v "$cmd")"; else printf 'MISSING %s\n' "$cmd"; fi
done
