from fastapi.testclient import TestClient
from app.main import app

def test_health():
    with TestClient(app) as client:
        r=client.get("/api/v1/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

def test_storage_summary():
    with TestClient(app) as client:
        r=client.get("/api/v1/storage/summary")
        assert r.status_code == 200
        assert "mode" in r.json()
        assert 0 <= r.json()["used_percent"] <= 100

def test_backup_and_restore(tmp_path, monkeypatch):
    import app.services.backup as backup
    monkeypatch.setattr(backup, "BACKUP_DIR", tmp_path / "backups")
    monkeypatch.setattr(backup, "DATA_DIR", tmp_path / "data")
    src=tmp_path/"source"; src.mkdir(); (src/"hello.txt").write_text("hello linuxdr")
    result=backup.create_full(str(src))
    assert backup.verify(result["id"])["valid"] is True
    restored=backup.restore_test(result["id"])
    assert restored["valid"] is True
    assert (tmp_path/"data"/"restore-tests"/result["id"]/"source"/"hello.txt").read_text()=="hello linuxdr"

def test_prediction_insufficient():
    from app.services.intelligence import predict
    assert predict([])["available"] is False
