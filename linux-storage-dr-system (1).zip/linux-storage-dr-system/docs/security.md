# Security model and limitations

- Localhost binding by default; do not expose without authentication, TLS, firewalling, and a security review.
- Simulation mode is the default.
- Live storage discovery uses read-only commands only.
- No root shell, arbitrary command endpoint, sudo configuration, formatting, partitioning, or LVM mutation.
- Backup source paths must be selected only from data you are authorized to access.
- Archives are checksum-verified before test restore and extracted to a separate destination.
- SQLite is local application data; protect the project directory with OS permissions.
- This is an academic starter, not a hardened multi-user production service.
