# Disaster recovery runbook

1. Confirm the selected backup is listed as completed.
2. Run verification; proceed only when SHA-256 and archive checks both pass.
3. Use Restore test first. The application extracts into `data/restore-tests/<backup-id>/`.
4. Compare expected files and contents in that isolated directory.
5. Record the backup ID, validation output, and test date.
6. Never restore over original data from this starter. Production recovery requires a separately reviewed procedure, access control, and tested backup-chain support.

RPO/RTO are not guaranteed by this project. Measure them during repeated recovery drills and record observed results.
