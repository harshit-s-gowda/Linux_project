import hashlib, json, tarfile, uuid, shutil
from datetime import datetime, timezone
from pathlib import Path
from ..config import BACKUP_DIR, DATA_DIR
from ..db import connection

def now(): return datetime.now(timezone.utc).isoformat()
def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()

def list_backups():
    with connection() as c:
        return [dict(r) for r in c.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()]

def create_full(source: str):
    src = Path(source).expanduser().resolve()
    if not src.exists() or not src.is_dir(): raise ValueError("Source must be an existing directory")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    bid = str(uuid.uuid4())
    dest = BACKUP_DIR / f"full-{bid}.tar.gz"
    temp = BACKUP_DIR / f".{bid}.tmp"
    created = now()
    try:
        with tarfile.open(temp, "w:gz") as tar:
            tar.add(src, arcname=src.name, recursive=True)
        temp.replace(dest)
        digest = sha256(dest)
        size = dest.stat().st_size
        with connection() as c:
            c.execute("INSERT INTO jobs(id,kind,source,artifact,created_at,status,size_bytes,sha256,details) VALUES(?,?,?,?,?,?,?,?,?)",
                      (bid,"full",str(src),str(dest),created,"completed",size,digest,"Archive created and SHA-256 recorded"))
        return {"id":bid,"kind":"full","source":str(src),"artifact":str(dest),"created_at":created,
                "status":"completed","size_bytes":size,"sha256":digest}
    except Exception as e:
        temp.unlink(missing_ok=True)
        with connection() as c:
            c.execute("INSERT OR REPLACE INTO jobs(id,kind,source,artifact,created_at,status,size_bytes,sha256,details) VALUES(?,?,?,?,?,?,?,?,?)",
                      (bid,"full",str(src),str(dest),created,"failed",0,None,str(e)))
        raise

def verify(backup_id):
    with connection() as c:
        row = c.execute("SELECT * FROM jobs WHERE id=?", (backup_id,)).fetchone()
    if not row: raise KeyError("Backup not found")
    p = Path(row["artifact"])
    if row["status"] != "completed" or not p.is_file(): return {"valid":False,"reason":"Completed archive is missing"}
    actual = sha256(p)
    checksum_ok = actual == row["sha256"]
    archive_ok = False
    try:
        with tarfile.open(p, "r:gz") as tar:
            archive_ok = tarfile.is_tarfile(p) and all(m.name and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in tar.getmembers())
    except (tarfile.TarError, OSError): pass
    return {"valid":bool(checksum_ok and archive_ok),"checksum_ok":checksum_ok,"archive_ok":archive_ok,
            "expected_sha256":row["sha256"],"actual_sha256":actual}

def restore_test(backup_id):
    check = verify(backup_id)
    if not check["valid"]: raise ValueError("Backup verification failed; refusing restore")
    with connection() as c:
        row = c.execute("SELECT * FROM jobs WHERE id=?", (backup_id,)).fetchone()
    destroot = DATA_DIR / "restore-tests" / backup_id
    destroot.mkdir(parents=True, exist_ok=False)
    try:
        with tarfile.open(row["artifact"], "r:gz") as tar:
            root = destroot.resolve()
            for member in tar.getmembers():
                target = (destroot / member.name).resolve()
                if target != root and root not in target.parents:
                    raise ValueError("Unsafe archive path rejected")
            tar.extractall(destroot, filter="data")
        files = sum(1 for p in destroot.rglob("*") if p.is_file())
        return {"valid":True,"destination":str(destroot),"files_restored":files,"backup_id":backup_id}
    except Exception:
        shutil.rmtree(destroot, ignore_errors=True)
        raise
