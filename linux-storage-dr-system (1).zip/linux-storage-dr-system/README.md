# AI-Driven Intelligent Linux Storage & Disaster Recovery System

A safe, local-first academic project starter for Ubuntu. It includes a FastAPI backend, SQLite persistence, a React/Vite dashboard, real read-only Linux discovery where supported, simulation mode, checksum-verified full backups, isolated restore tests, basic storage-growth analysis, alerts, and tests.

**Safety defaults:** simulation mode is enabled; infrastructure discovery is read-only; the app binds to localhost; backup/restore work on configured application paths. No root privileges are required. This starter does not format disks, repartition devices, or execute arbitrary shell commands.

## Requirements
- Ubuntu Linux
- Python 3.11+ (Python 3.14 may require newer dependency wheels; Python 3.12 is a good default)
- Node.js 20+ and npm

## Quick start
From the extracted project directory:

```bash
chmod +x install.sh start.sh stop.sh
./install.sh
./start.sh
```

Open:
- Frontend: http://127.0.0.1:5173
- API docs: http://127.0.0.1:8000/docs
- API health: http://127.0.0.1:8000/api/v1/health

Stop with `./stop.sh`.

## Simulation and live discovery
The app starts in simulation mode. To enable read-only host discovery, stop the app, set `SIMULATION_MODE=false` in `backend/.env`, then restart. Live mode only reads `df`, `lsblk`, and optional LVM reporting commands. It does not perform storage changes. The dashboard labels simulation data clearly.

## Backup demonstration
1. Open Backup & Recovery.
2. Set a source directory that you own, for example `./sample-data`.
3. Click Create full backup.
4. Click Verify on the created backup.
5. Run Restore test to extract to a separate directory under `data/restore-tests/`.
6. Inspect job history in the page or `backups/manifest.json`.

The included `sample-data/` folder is safe test content. Never use a production data directory for an initial demonstration.

## Tests
```bash
cd backend
../.venv/bin/pytest -q
```

## Architecture
- `backend/app/main.py`: FastAPI routes and application setup
- `backend/app/services/`: storage discovery, backup/restore, and simple statistical analysis
- `backend/app/db.py`: SQLite persistence
- `frontend/src/`: React UI calling the backend
- `scripts/`: safe optional Linux helper scripts

## Limitations
This is a runnable baseline, not a claim that every feature in the master specification is complete. Live LVM mutation, privileged operations, production authentication, systemd scheduling, email delivery, incremental-chain restoration, and PDF reporting are not enabled in this starter. Such operations should be added only with explicit authorization, dedicated test devices, and integration testing. Never expose this development server to the public internet.
