#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
command -v python3 >/dev/null || { echo "Install Python 3 first: sudo apt update && sudo apt install -y python3 python3-venv python3-pip"; exit 1; }
command -v npm >/dev/null || { echo "Install Node.js 20+ and npm first. Then rerun ./install.sh"; exit 1; }
mkdir -p data backups logs reports
if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install -r backend/requirements.txt
if [[ ! -f backend/.env ]]; then cp backend/.env.example backend/.env; fi
cd frontend
npm install
cd "$ROOT"
mkdir -p sample-data
if [[ ! -f sample-data/readme.txt ]]; then printf 'LinuxDR safe sample dataset\nThis file is for backup and restore testing only.\n' > sample-data/readme.txt; fi
echo "Installation complete. Run ./start.sh"
