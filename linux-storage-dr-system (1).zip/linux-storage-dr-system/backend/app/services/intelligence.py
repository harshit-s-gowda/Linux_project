def predict(points, threshold=90):
    # points are chronological objects with used_percent and captured_at
    if len(points) < 3:
        return {"available":False,"reason":"At least three historical measurements are required","method":"linear growth estimate"}
    vals = [float(p["used_percent"]) for p in points]
    times = [float(i) for i in range(len(vals))]
    n = len(vals); xm=sum(times)/n; ym=sum(vals)/n
    denom=sum((x-xm)**2 for x in times)
    slope=sum((x-xm)*(y-ym) for x,y in zip(times,vals))/denom if denom else 0
    if slope <= 0:
        return {"available":False,"reason":"Observed utilization is flat or decreasing; no reliable exhaustion estimate","method":"ordinary least-squares trend"}
    remaining=(threshold-vals[-1])/slope
    if remaining <= 0: remaining=0
    return {"available":True,"method":"ordinary least-squares trend over collected samples",
            "current_percent":vals[-1],"growth_percentage_points_per_sample":round(slope,3),
            "threshold_percent":threshold,"estimated_samples_to_threshold":round(remaining,1),
            "confidence":"low: sample count and real elapsed-time spacing are not modeled",
            "recommendation":"Review large directories, clean only approved data, and plan capacity expansion."}
