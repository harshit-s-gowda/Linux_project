# Architecture

```mermaid
flowchart LR
  UI[React + Vite UI] -->|REST /api/v1| API[FastAPI]
  API --> S[Storage discovery service]
  API --> B[Backup and restore service]
  API --> I[Statistical analysis]
  S --> Linux[Read-only Linux utilities]
  B --> FS[Project backup directory]
  API --> DB[(SQLite)]
```

The browser only calls typed API endpoints. Infrastructure commands are isolated in the storage service and use fixed argument arrays. Default simulation mode returns explicitly labeled synthetic resources. Backups operate on a user-selected directory and restore tests go to a separate generated destination.
