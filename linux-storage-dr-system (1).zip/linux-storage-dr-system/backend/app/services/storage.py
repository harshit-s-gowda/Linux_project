import json, shutil, subprocess
from pathlib import Path
from ..config import SIMULATION_MODE, WARNING_THRESHOLD, CRITICAL_THRESHOLD

def _run(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=8, check=False)
        if p.returncode != 0:
            return None
        return p.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, PermissionError):
        return None

def discover():
    if SIMULATION_MODE:
        devices = [{"name": "/dev/simulated-root", "size_bytes": 100*1024**3,
                    "type": "disk", "mountpoint": "/", "filesystem": "ext4",
                    "used_bytes": 62*1024**3, "used_percent": 62.0, "source": "simulation"}]
        return {"mode": "simulation", "devices": devices, "lvm": {"available": False, "physical_volumes": [], "volume_groups": [], "logical_volumes": []}}
    rows = []
    df = _run(["df", "-B1", "-P", "-T"])
    if df:
        for line in df.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 7:
                try:
                    total, used = int(parts[2]), int(parts[3])
                    rows.append({"name": parts[0], "filesystem": parts[1], "size_bytes": total,
                                 "used_bytes": used, "used_percent": round(used/total*100, 2) if total else 0,
                                 "mountpoint": parts[6], "type": "filesystem", "source": "host"})
                except ValueError:
                    continue
    lsblk = _run(["lsblk", "-J", "-b", "-o", "NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT"])
    if lsblk:
        try:
            raw = json.loads(lsblk).get("blockdevices", [])
            for d in raw:
                rows.append({"name": "/dev/" + str(d.get("name", "")), "size_bytes": int(d.get("size") or 0),
                             "type": d.get("type") or "unknown", "filesystem": d.get("fstype"),
                             "mountpoint": d.get("mountpoint"), "used_bytes": 0, "used_percent": 0, "source": "host"})
        except (ValueError, TypeError):
            pass
    lvm = {"available": bool(shutil.which("pvs") and shutil.which("vgs") and shutil.which("lvs")),
           "physical_volumes": [], "volume_groups": [], "logical_volumes": []}
    if lvm["available"]:
        for cmd, key in [(["pvs","--reportformat","json","-o","pv_name,pv_size,pv_free"], "physical_volumes"),
                         (["vgs","--reportformat","json","-o","vg_name,vg_size,vg_free"], "volume_groups"),
                         (["lvs","--reportformat","json","-o","lv_name,vg_name,lv_size,lv_attr"], "logical_volumes")]:
            out = _run(cmd)
            if out:
                try: lvm[key] = json.loads(out).get("report", [{}])[0].get(key.split("_")[0], [])
                except (ValueError, IndexError, AttributeError): pass
    return {"mode": "live-read-only", "devices": rows, "lvm": lvm}

def thresholds_for(percent):
    if percent >= CRITICAL_THRESHOLD: return "critical"
    if percent >= WARNING_THRESHOLD: return "warning"
    return "healthy"
