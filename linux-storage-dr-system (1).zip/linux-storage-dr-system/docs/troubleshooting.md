# Troubleshooting

- `npm: command not found`: install Node.js 20+ and npm, then rerun `./install.sh`.
- Python package errors: use Python 3.11 or 3.12, delete `.venv`, and rerun `./install.sh`.
- API unreachable: inspect `logs/backend.log`, then run `curl http://127.0.0.1:8000/api/v1/health`.
- Frontend unreachable: inspect `logs/frontend.log`; check whether port 5173 is already in use.
- Backup source error: choose an existing directory that the current user can read.
- Restore-test refuses to run: verify the backup first; corrupted or missing archives are rejected.
- LVM not available: install `lvm2` for read-only reporting. No LVM changes are supported by default.
