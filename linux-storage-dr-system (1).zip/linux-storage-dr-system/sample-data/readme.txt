LinuxDR sample data. Safe to use for backup/restore demonstrations.
