from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from datetime import datetime, timezone
import shutil, platform, os
from .config import SIMULATION_MODE, WARNING_THRESHOLD, CRITICAL_THRESHOLD, BACKUP_DIR
from .db import init_db, connection
from .services.storage import discover, thresholds_for
from .services.backup import create_full, list_backups, verify, restore_test
from .services.intelligence import predict

app = FastAPI(title="LinuxDR API", version="1.0.0", description="Safe local Linux storage monitoring and disaster-recovery demo")
app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:5173","http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def startup(): init_db()

class BackupRequest(BaseModel):
    source: str = Field(min_length=1, max_length=1024)

@app.get("/api/v1/health")
def health():
    return {"status":"ok","mode":"simulation" if SIMULATION_MODE else "live-read-only","timestamp":datetime.now(timezone.utc).isoformat()}

@app.get("/api/v1/system/info")
def system_info():
    return {"hostname":platform.node(),"platform":platform.platform(),"python":platform.python_version(),
            "mode":"simulation" if SIMULATION_MODE else "live-read-only"}

@app.get("/api/v1/system/dependencies")
def dependencies():
    names=["df","lsblk","pvs","vgs","lvs","rsync","tar","gzip"]
    return {"dependencies":[{"name":n,"available":shutil.which(n) is not None} for n in names]}

@app.get("/api/v1/storage/summary")
def storage_summary():
    data=discover()
    total=sum(d.get("size_bytes",0) for d in data["devices"] if d.get("type") in ("disk","filesystem"))
    used=sum(d.get("used_bytes",0) for d in data["devices"] if d.get("type") in ("filesystem",))
    pct=round(used/total*100,2) if total else 0
    return {"mode":data["mode"],"device_count":len(data["devices"]),"total_bytes":total,"used_bytes":used,
            "available_bytes":max(total-used,0),"used_percent":pct,"health":thresholds_for(pct),
            "warning_threshold":WARNING_THRESHOLD,"critical_threshold":CRITICAL_THRESHOLD}

@app.get("/api/v1/storage/devices")
def storage_devices(): return discover()

@app.get("/api/v1/monitoring/current")
def monitoring_current():
    data=discover()
    captured=datetime.now(timezone.utc).isoformat()
    with connection() as c:
        for d in data["devices"]:
            if d.get("type") in ("filesystem","disk"):
                c.execute("INSERT INTO metrics(captured_at,resource,total_bytes,used_bytes,used_percent,source) VALUES(?,?,?,?,?,?)",
                          (captured,d.get("name","unknown"),d.get("size_bytes",0),d.get("used_bytes",0),d.get("used_percent",0),data["mode"]))
                pct=d.get("used_percent",0); severity=thresholds_for(pct)
                if severity in ("warning","critical"):
                    key=f"storage:{d.get('name')}:{severity}"
                    c.execute("INSERT OR IGNORE INTO alerts(key,severity,title,description,created_at) VALUES(?,?,?,?,?)",
                              (key,severity,f"Storage {severity}: {d.get('name')}",f"Utilization is {pct}%. Review capacity.",captured))
    return {"captured_at":captured,**data}

@app.get("/api/v1/monitoring/history")
def monitoring_history():
    with connection() as c: return [dict(r) for r in c.execute("SELECT * FROM metrics ORDER BY id DESC LIMIT 100").fetchall()][::-1]

@app.get("/api/v1/storage/lvm")
def storage_lvm(): return discover()["lvm"]

@app.get("/api/v1/backups")
def backups(): return list_backups()

@app.post("/api/v1/backups/full")
def backup_full(req: BackupRequest):
    try: return create_full(req.source)
    except ValueError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(500,f"Backup failed: {e}")

@app.post("/api/v1/backups/{backup_id}/verify")
def backup_verify(backup_id: str):
    try: return verify(backup_id)
    except KeyError as e: raise HTTPException(404,str(e))

@app.post("/api/v1/backups/{backup_id}/restore-test")
def backup_restore_test(backup_id: str):
    try: return restore_test(backup_id)
    except KeyError as e: raise HTTPException(404,str(e))
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/api/v1/alerts")
def alerts():
    with connection() as c: return [dict(r) for r in c.execute("SELECT * FROM alerts ORDER BY created_at DESC LIMIT 100").fetchall()]

@app.post("/api/v1/alerts/{alert_id}/acknowledge")
def acknowledge(alert_id: int):
    with connection() as c:
        cur=c.execute("UPDATE alerts SET acknowledged=1 WHERE id=?",(alert_id,))
        if cur.rowcount == 0: raise HTTPException(404,"Alert not found")
    return {"id":alert_id,"acknowledged":True}

@app.get("/api/v1/intelligence/summary")
def intelligence_summary():
    with connection() as c: points=[dict(r) for r in c.execute("SELECT captured_at,used_percent FROM metrics ORDER BY id DESC LIMIT 20").fetchall()][::-1]
    return predict(points)

@app.get("/api/v1/jobs")
def jobs(): return list_backups()
