import sqlite3
from contextlib import contextmanager
from .config import DB_PATH, DATA_DIR

def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT, captured_at TEXT NOT NULL,
            resource TEXT NOT NULL, total_bytes INTEGER NOT NULL,
            used_bytes INTEGER NOT NULL, used_percent REAL NOT NULL, source TEXT NOT NULL)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, kind TEXT NOT NULL, source TEXT NOT NULL,
            artifact TEXT NOT NULL, created_at TEXT NOT NULL, status TEXT NOT NULL,
            size_bytes INTEGER DEFAULT 0, sha256 TEXT, details TEXT DEFAULT '')''')
        conn.execute('''CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL UNIQUE,
            severity TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL,
            created_at TEXT NOT NULL, acknowledged INTEGER DEFAULT 0, resolved INTEGER DEFAULT 0)''')
        conn.commit()

@contextmanager
def connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()
