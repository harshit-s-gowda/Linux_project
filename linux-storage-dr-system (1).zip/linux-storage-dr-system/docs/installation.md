# Installation

1. Install Python 3, venv, Node.js 20+, npm, and curl.
2. Extract ZIP and enter `linux-storage-dr-system/`.
3. Run `chmod +x install.sh start.sh stop.sh && ./install.sh`.
4. Run `./start.sh`.
5. Open `http://127.0.0.1:5173` and API docs at `http://127.0.0.1:8000/docs`.

Logs are written to `logs/backend.log` and `logs/frontend.log`. Stop using `./stop.sh`. For startup errors, check the logs and run `curl http://127.0.0.1:8000/api/v1/health`.
